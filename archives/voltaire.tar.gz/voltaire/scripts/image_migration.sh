mkdir -p /usr/local/etc/dic/images
cp images/* /usr/local/etc/dic/images
