# this script brings the articles you made on to the git repo

mkdir -p pages
cp /usr/local/etc/dic/* pages
